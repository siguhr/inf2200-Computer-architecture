#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// Declaring that assembly function is provided elsewhere
extern void asm_function();

// This should be the C equivalent to the assembly implementation
void c_function() {
	
}

int main(int argc, char **argv) {

	/* Start here */
	
}
